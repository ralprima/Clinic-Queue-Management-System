const Pages={};
const ROLES=['admin','receptionist','doctor'];
const Can=(role,page)=>!!Pages[page]&&Pages[page].roles.includes(role);
const sha=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
const Auth={user:null,
 async hash(p,salt=Math.random().toString(36).slice(2)){return salt+':'+await sha(salt+p)},
 async check(p,h){const[s]=h.split(':');return h===await Auth.hash(p,s)},
 async init(){DB.seed();if(DB.get('users').length)return;const doc=DB.get('doctors')[0];
  for(const[u,r]of[['admin','admin'],['reception','receptionist'],['doctor','doctor']])DB.add('users',{username:u,role:r,hash:await Auth.hash('Passw0rd!'),doctorId:r==='doctor'?doc.id:null,active:true})},
 async login(u,p){const x=DB.get('users').find(r=>r.username===u&&r.active);
  if(!x||!await Auth.check(p,x.hash))throw Error('Incorrect username or password');Auth.user=x;DB.log('Login');return x},
 logout(){DB.log('Logout');Auth.user=null}};
