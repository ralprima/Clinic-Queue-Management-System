function App(){return html`<div style=${{padding:20}}><h1>Clinic Queue Management System</h1><p>Auth ready: ${DB.get('users').length} demo accounts, passwords stored as salted hashes.</p></div>`}
Auth.init().then(()=>{DB.seed();ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`)});
