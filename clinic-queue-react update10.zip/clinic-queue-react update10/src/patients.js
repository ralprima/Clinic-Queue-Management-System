const age=d=>d?Math.floor((Date.now()-new Date(d))/31557600000):'';
const phoneOk=p=>/^[+\d][\d\s-]{6,14}$/.test(p);
Pages.Patients={roles:['admin','receptionist'],C:()=>html`<${Crud} table=patients title="Patients" extra=${[{label:'Age',fn:r=>age(r.dob)}]}
 fields=${[{k:'first',label:'First name',req:1},{k:'mid',label:'Middle name'},{k:'last',label:'Last name',req:1},{k:'dob',label:'Date of birth',type:'date',req:1},
 {k:'gender',label:'Gender',opts:['Female','Male','Other'],req:1},{k:'phone',label:'Contact number',req:1},{k:'address',label:'Address'}]}
 validate=${(f,all)=>!phoneOk(f.phone)?'Enter a valid contact number':new Date(f.dob)>new Date()?'Date of birth cannot be in the future'
  :all.some(p=>p.id!==f.id&&p.first.toLowerCase()===f.first.toLowerCase()&&p.last.toLowerCase()===f.last.toLowerCase()&&p.dob===f.dob)?'This patient is already registered':''}/>`};
