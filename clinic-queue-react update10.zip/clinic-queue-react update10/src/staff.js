const deptName=id=>(DB.get('departments').find(d=>d.id===id)||{}).name||'';
const deptOpts=()=>DB.get('departments').filter(d=>d.active).map(d=>({v:d.id,t:d.name}));
Pages.Departments={roles:['admin'],C:()=>html`<${Crud} table=departments title="Departments and services"
 fields=${[{k:'name',label:'Department / service',req:1},{k:'code',label:'Queue code (2 letters)',req:1}]}
 validate=${(f,all)=>!/^[A-Za-z]{2}$/.test(f.code)?'Queue code must be 2 letters':all.some(d=>d.id!==f.id&&d.code.toUpperCase()===f.code.toUpperCase())?'Queue code already in use':''}/>`};
