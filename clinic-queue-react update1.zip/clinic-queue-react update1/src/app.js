// Entry point: mounts the React app.
const e=React.createElement;
ReactDOM.createRoot(document.getElementById('root')).render(e('h1',{style:{padding:20}},'Clinic Queue Management System'));
