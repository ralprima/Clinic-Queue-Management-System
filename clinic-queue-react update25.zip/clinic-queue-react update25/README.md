# Clinic Queue Management System (React)

React port of the C# WinForms/MySQL specification. Runs as static files; open `index.html` (or `npx serve .`) in Chrome/Edge. React and htm load from CDN, so the first run needs internet.

**Demo logins** (password `Passw0rd!`): `admin`, `reception`, and one personal account per doctor: `dr.reyes` (General Consultation), `dr.bautista` (Dental), `dr.santos` (Pediatrics), `dr.torres` (Laboratory). Everyone can change their own password under **My account**. Live TV display: `index.html#display` (or the **Live display** link in the sidebar, which opens it in its own tab).

## Structure
`src/db.js` data layer + seed (4 departments, 1 doctor each) · `ui.js` shared icons, avatars, status badges · `auth.js` login, hashing, roles · `crud.js` shared table/form · `patients.js`, `staff.js` (doctors, departments, accounts), `queue.js`, `appointments.js`, `display.js`, `notify.js`, `reports.js` (reports, logs, settings) · `test/run.js` logic tests (`npm test`).

## Design
Clean clinical theme (Inter font, navy sidebar, status badges, avatar initials), a split-screen login, a dashboard with doctor list, a full-screen TV display and a responsive layout down to phone width. Colours and spacing are CSS variables at the top of `style.css`.

## Differences from the spec
- **Storage is browser localStorage, not MySQL.** Data lives in one browser; there is no server, so the TV display must run in the same browser profile. A Node/Express + MySQL API behind `DB` is the next step.
- Passwords use salted SHA-256 in the browser (demo-grade, not BCrypt) and role checks are client-side only.
- Excel export is CSV; PDF is the browser's Print → Save as PDF.
- Not built: separate clinic-services table, per-slot doctor schedules (free-text schedule only), consultation notes/diagnosis form, queue-format and priority settings, creating admin/reception accounts from the UI (doctor accounts are automatic; the Accounts screen lists logins and resets passwords), forced password change on first login, SQL scripts.
- Priority: Senior, PWD and Pregnant share one tier ahead of Regular, first-come within tier. Adjust `PRI` in `queue.js` to match your clinic policy.

## Doctors and accounts
- **One doctor per department.** The Doctors screen refuses a second active doctor in a department (add, edit or re-activate). To replace a doctor, deactivate the old one first, then add the new one.
- **One personal login per doctor.** Accounts are created automatically (`dr.<email name>`, default password `Passw0rd!`) and follow the doctor record: deactivating a doctor disables their login, re-activating restores it. Admin sees every login under **Accounts** and can reset passwords.
- **Upgrading an existing install:** on first load the old roster is trimmed to one active doctor per department (extras are deactivated, not deleted, so queue history keeps their names) and the shared `doctor` login is renamed to that doctor's personal username.
- Because a department has exactly one doctor, the queue assigns it automatically; the doctor can't be picked or overridden at the desk.

## System flow
1. **Setup (admin):** departments (each with a 2-letter queue code) and one doctor per department. Each doctor gets a personal login.
2. **Registration (reception/admin):** patient is registered once (duplicate check on name + birth date).
3. **Booking (optional):** an appointment is booked for a department; its doctor is filled in automatically and double-booking the same slot is blocked.
4. **Arrival (reception):** reception issues a queue number (e.g. `PD-004`) for the chosen department, or clicks **Patient arrived** on today's appointment. The department's doctor is attached automatically. Senior, PWD and Pregnant patients go ahead of Regular; a patient can't have two active tickets.
5. **Waiting room:** the live display (`#display`) shows the number being served and the next in line, numbers only, no names.
6. **Doctor signs in with their own account** and sees only their department's queue. **Call next** calls the first waiting patient (priority first, then first-come). Then: *Start* consultation → *Complete*; or *Recall*, *Skip* (back of the line) or *No-show*.
7. **Throughout:** every action is written to the activity log and raises a bell notification; the dashboard shows the day's counts (doctors see only their own department).
8. **Admin:** reports (daily/weekly/monthly, CSV or print to PDF), activity logs, accounts, settings and backup.

## Tests
`npm test` covers login, hashing, roles, one-doctor-per-department, individual doctor accounts (create, rename, enable/disable, password change), roster migration, queue numbering and doctor auto-assignment, priority, duplicates, skip/cancel, appointment conflicts. UI screens were not exercised in a browser.
