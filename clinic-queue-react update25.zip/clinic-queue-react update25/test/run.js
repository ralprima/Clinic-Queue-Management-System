// Logic tests: loads the real source files in a sandbox with a fake localStorage.
const vm=require('vm'),fs=require('fs'),assert=require('assert');
const store={},ctx=vm.createContext({localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)},crypto:globalThis.crypto,TextEncoder,
 React:{useState:()=>[0,()=>{}],useEffect(){},createElement:()=>null},htm:{bind:()=>()=>null},document:{},location:{hash:''},URL,Blob,setInterval(){}});
for(const f of['db','ui','auth','crud','patients','staff','queue','appointments','display','notify','reports'])vm.runInContext(fs.readFileSync(`src/${f}.js`,'utf8'),ctx,{filename:f});
const R=s=>vm.runInContext(s,ctx);let n=0;const t=async(name,fn)=>{await fn();console.log('✓',name);n++};
(async()=>{
 await R('Auth.init()');
 await t('seeded 4 departments, 4 doctors and 6 accounts',()=>{assert.equal(R('DB.get("departments").length'),4);assert.equal(R('DB.get("doctors").length'),4);assert.equal(R('DB.get("users").length'),6)});
 await t('exactly one active doctor per department, unique emails',()=>{const ds=R('DB.get("doctors")');assert.equal(new Set(ds.map(d=>d.email)).size,ds.length);
  for(const d of R('DB.get("departments")'))assert.equal(ds.filter(x=>x.deptId===d.id&&x.active).length,1,'department '+d.name)});
 await t('re-running the roster migration is idempotent',()=>{delete store.cq_roster;R('DB.seed()');R('DB.seed()');assert.equal(R('DB.get("doctors").length'),4)});
 await t('every doctor has an individual login (unique username, linked to that doctor)',async()=>{const us=R('DB.get("users").filter(u=>u.role==="doctor")'),ds=R('DB.get("doctors")');
  assert.equal(us.length,4);assert.equal(new Set(us.map(u=>u.username)).size,4);assert.equal(new Set(us.map(u=>u.doctorId)).size,4);
  assert(!us.some(u=>u.username==='doctor'),'shared login should not exist');
  const reyes=ds.find(d=>d.email==='reyes@clinic.ph'),u=await R('Auth.login("DR.Reyes ","Passw0rd!")');assert.equal(u.username,'dr.reyes');assert.equal(u.doctorId,reyes.id);
  assert.equal(R('deptOfDoctor("'+reyes.id+'")'),R('DB.get("departments").find(d=>d.code==="GC").id'))});
 await t('legacy install: extra doctors deactivated, shared "doctor" login renamed',async()=>{
  const gc=R('DB.get("departments")[0].id'),reyes=R('DB.get("doctors").find(d=>d.email==="reyes@clinic.ph").id'),uid=R(`DB.get("users").find(u=>u.doctorId==="${reyes}").id`);
  R(`DB.add("doctors",{name:"Dr. Extra",spec:"x",deptId:"${gc}",email:"extra@clinic.ph",avail:"Available",active:true})`);R(`DB.upd("users","${uid}",{username:"doctor"})`);
  delete store.cq_roster;R('DB.seed()');await R('Auth.syncDoctors()');
  assert.equal(R(`DB.get("doctors").filter(d=>d.active&&d.deptId==="${gc}").length`),1);
  assert.equal(R('DB.get("doctors").find(d=>d.email==="extra@clinic.ph").active'),false);
  assert.equal(R(`DB.get("users").find(u=>u.id==="${uid}").username`),'dr.reyes');
  assert.equal(R('DB.get("users").filter(u=>u.role==="doctor").length'),4,'inactive doctors get no account')});
 await t('deactivating a doctor disables their login; reactivating restores it',async()=>{
  const id=R('DB.get("doctors").find(d=>d.email==="torres@clinic.ph").id');R(`DB.upd("doctors","${id}",{active:false})`);await R('Auth.syncDoctors()');
  await assert.rejects(R('Auth.login("dr.torres","Passw0rd!")'));R(`DB.upd("doctors","${id}",{active:true})`);await R('Auth.syncDoctors()');
  assert.equal((await R('Auth.login("dr.torres","Passw0rd!")')).doctorId,id)});
 await t('one-doctor-per-department rule',()=>{const gc=R('DB.get("departments")[0].id'),all=R('DB.get("doctors")'),reyes=all.find(d=>d.email==='reyes@clinic.ph');
  assert(R(`docDeptTaken({deptId:"${gc}"},DB.get("doctors"))`),'new doctor blocked');
  assert(!R(`docDeptTaken(${JSON.stringify(reyes)},DB.get("doctors"))`),'editing the department\'s own doctor is fine');
  assert(!R(`docDeptTaken({id:"x",active:false,deptId:"${gc}"},DB.get("doctors"))`),'inactive record may be edited');
  const extra=all.find(d=>d.email==='extra@clinic.ph');assert(R(`docDeptTaken(${JSON.stringify({...extra,active:true})},DB.get("doctors"))`),'reactivation blocked')});
 await t('login succeeds and rejects bad password',async()=>{assert.equal((await R('Auth.login("admin","Passw0rd!")')).role,'admin');await assert.rejects(R('Auth.login("admin","x")'))});
 await t('passwords are stored hashed',()=>assert(!R('JSON.stringify(DB.get("users"))').includes('Passw0rd!')));
 await t('users can change their own password; wrong/short passwords are rejected',async()=>{await R('Auth.login("dr.reyes","Passw0rd!")');
  await assert.rejects(R('Auth.changePassword("nope","NewPassw0rd1")'),/Current password/);await assert.rejects(R('Auth.changePassword("Passw0rd!","short")'),/at least 8/);
  await R('Auth.changePassword("Passw0rd!","NewPassw0rd1")');assert.equal((await R('Auth.login("dr.reyes","NewPassw0rd1")')).username,'dr.reyes');await assert.rejects(R('Auth.login("dr.reyes","Passw0rd!")'));
  const id=R('Auth.user.id');await R(`Auth.setPassword("${id}","Passw0rd!")`);await R('Auth.login("admin","Passw0rd!")')});
 await t('role permissions',()=>{assert(R('Can("admin","Accounts")'));assert(!R('Can("doctor","Accounts")'));assert(!R('Can("receptionist","Accounts")'));assert(R('Can("admin","Reports")'));assert(!R('Can("doctor","Reports")'));assert(!R('Can("receptionist","Doctors")'));assert(R('Can("doctor","Queue")'))});
 R('["a","b","c","e"].forEach(x=>DB.add("patients",{first:x,last:"T",dob:"1990-01-01",active:true}))');
 const [a,b,c,e]=R('DB.get("patients").map(p=>p.id)'),dept=R('DB.get("departments")[0].id');
 await t('queue numbers are sequential per department/day',()=>{R(`Q.issue({patientId:"${a}",deptId:"${dept}"})`);assert.equal(R(`Q.issue({patientId:"${b}",deptId:"${dept}"}).no`),'GC-002')});
 await t('duplicate active entry is blocked',()=>assert.throws(()=>R(`Q.issue({patientId:"${a}",deptId:"${dept}"})`),/active queue/));
 await t('queue entry is assigned to the department\'s only doctor; department without a doctor is refused',()=>{
  const doc=R(`DB.get("doctors").find(d=>d.deptId==="${dept}"&&d.active)`);assert.equal(R(`DB.get("queues")[0].doctorId`),doc.id);
  const dn=R('DB.get("departments").find(d=>d.code==="DN").id'),dd=R(`DB.get("doctors").find(d=>d.deptId==="${dn}"&&d.active)`);
  const bogus=R(`Q.issue({patientId:"${e}",deptId:"${dn}",doctorId:"someone-else"}).doctorId`);assert.equal(bogus,dd.id,'caller-supplied doctor is ignored');R(`Q.set(DB.get("queues").slice(-1)[0].id,"Cancelled")`);
  const nd=R('DB.add("departments",{name:"X-Ray",code:"XR",active:true}).id');assert.throws(()=>R(`Q.issue({patientId:"${e}",deptId:"${nd}"})`),/no active doctor/)});
 await t('priority patients are called first',()=>{R(`Q.issue({patientId:"${c}",deptId:"${dept}",priority:"Senior"})`);assert.equal(R('Q.callNext().no'),'GC-003')});
 await t('skip moves patient to back; cancel removes from waiting',()=>{const id=R('Q.waiting()[0].id');R(`Q.skip("${id}")`);assert.equal(R('Q.waiting().length'),2);R(`Q.set("${id}","Cancelled")`);assert.equal(R('Q.waiting().length'),1)});
 await t('appointment conflicts detected',()=>{const x={id:'1',doctorId:'d',date:'2030-01-01',time:'09:00',status:'Scheduled'};assert(R(`Appt.conflict({id:'2',doctorId:'d',date:'2030-01-01',time:'09:00'},[${JSON.stringify(x)}])`));assert(!R(`Appt.conflict({id:'2',doctorId:'d',date:'2030-01-01',time:'10:00'},[${JSON.stringify(x)}])`))});
 await t('events create notifications and logs',()=>{assert(R('DB.get("notifications").length')>0);assert(R('DB.get("activity_logs").length')>0)});
 console.log(n+' tests passed');
})().catch(e=>{console.error('✗',e.message);process.exit(1)});
