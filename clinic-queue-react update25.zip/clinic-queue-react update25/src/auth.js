const Pages={};
const ROLES=['admin','receptionist','doctor'];
const Can=(role,page)=>!!Pages[page]&&Pages[page].roles.includes(role);
const sha=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
const Auth={user:null,
 async hash(p,salt=Math.random().toString(36).slice(2)){return salt+':'+await sha(salt+p)},
 async check(p,h){const[s]=h.split(':');return h===await Auth.hash(p,s)},
 PW:'Passw0rd!',// demo default for new accounts; people should change it under "My account"
 async init(){DB.seed();
  if(!DB.get('users').length)for(const[u,r]of[['admin','admin'],['reception','receptionist']])DB.add('users',{username:u,role:r,hash:await Auth.hash(Auth.PW),doctorId:null,active:true});
  await Auth.syncDoctors()},
 // Unique login name for a doctor, e.g. reyes@clinic.ph -> dr.reyes
 uname(d){const base='dr.'+(d.email||d.name).split('@')[0].toLowerCase().replace(/[^a-z0-9.]/g,'');let n=base,i=2;while(DB.get('users').some(x=>x.username===n))n=base+i++;return n},
 // One personal account per doctor. Creates missing ones, renames the old shared "doctor" login, and keeps account status in step with the doctor record.
 async syncDoctors(){for(const d of DB.get('doctors')){const u=DB.get('users').find(x=>x.role==='doctor'&&x.doctorId===d.id);
   if(!u){if(d.active)DB.add('users',{username:Auth.uname(d),role:'doctor',doctorId:d.id,hash:await Auth.hash(Auth.PW),active:true})}
   else{const p={};if(u.username==='doctor')p.username=Auth.uname(d);if(u.active!==d.active)p.active=d.active;if(Object.keys(p).length)DB.upd('users',u.id,p)}}},
 async setPassword(id,p,msg='Password changed'){if(String(p||'').length<8)throw Error('Password must be at least 8 characters');DB.upd('users',id,{hash:await Auth.hash(p)});DB.log(msg)},
 async changePassword(cur,p){if(!await Auth.check(cur,Auth.user.hash))throw Error('Current password is incorrect');
  await Auth.setPassword(Auth.user.id,p);Auth.user=DB.get('users').find(x=>x.id===Auth.user.id)},
 async login(u,p){u=String(u).trim().toLowerCase();const x=DB.get('users').find(r=>r.username.toLowerCase()===u&&r.active);
  if(!x||!await Auth.check(p,x.hash))throw Error('Incorrect username or password');Auth.user=x;DB.log('Login');return x},
 logout(){DB.log('Logout');Auth.user=null}};
function Login({onLogin}){const[u,setU]=useState(''),[p,setP]=useState(''),[e,setE]=useState('');
 const go=async()=>{try{onLogin(await Auth.login(u,p))}catch(x){setE(x.message)}};
 const clinic=(DB.get('settings')[0]||{}).clinic||'Clinic Queue';
 return html`<div class=auth><div class=auth-art><div class=brand><span class=logo><${Icon} n=cross size=22/></span><div><b>${clinic}</b><small>Queue Management System</small></div></div>
 <div><h1>Shorter waits.<br/>Better care.</h1><p>One place for patient registration, queue numbers, appointments and live waiting-room displays.</p>
 <ul class=feats><li><span class=ico><${Icon} n=zap size=18/></span>Automatic queue numbers with priority lanes</li><li><span class=ico><${Icon} n=Appointments size=18/></span>Appointment scheduling with conflict checks</li><li><span class=ico><${Icon} n=shield size=18/></span>Role-based access for admin, reception and doctors</li></ul></div>
 <div class=auth-foot>Secure staff access only</div></div>
 <div class=auth-form><div class=auth-card><h2>Welcome back</h2><p class=muted>Sign in to your clinic account</p>
 <label>Username<input value=${u} onInput=${x=>setU(x.target.value)} autocomplete=username/></label>
 <label>Password<input type=password value=${p} onInput=${x=>setP(x.target.value)} onKeyDown=${x=>x.key==='Enter'&&go()} autocomplete=current-password/></label>
 <button onClick=${go}>Sign in</button><span class=err>${e}</span>
 <div class=demo>Demo accounts: <b>admin</b>, <b>reception</b><br/>Doctors: <b>dr.reyes</b> (General), <b>dr.bautista</b> (Dental), <b>dr.santos</b> (Pediatrics), <b>dr.torres</b> (Laboratory)<br/>Password: <b>Passw0rd!</b></div></div></div></div>`}

// "My account": every user (admin, reception, each doctor) can change their own password.
function Account(){const u=Auth.user,[f,setF]=useState({cur:'',pw:'',pw2:''}),[m,setM]=useState(''),[bad,setBad]=useState(false),set=k=>e=>setF({...f,[k]:e.target.value});
 const d=DB.get('doctors').find(x=>x.id===u.doctorId);
 const save=async()=>{try{if(f.pw!==f.pw2)throw Error('The new passwords do not match');await Auth.changePassword(f.cur,f.pw);setF({cur:'',pw:'',pw2:''});setBad(false);setM('Password updated.')}catch(e){setBad(true);setM(e.message)}};
 return html`<div><${PageHead} title="My account" sub="Your personal sign-in details"/>
 <div class=card><div class=cardhead><h3>Profile</h3></div><div class=grid><label>Username<input disabled value=${u.username}/></label><label>Role<input disabled value=${ROLE_LABEL[u.role]||u.role}/></label>
 ${d&&html`<label>Doctor<input disabled value=${d.name}/></label><label>Department<input disabled value=${deptName(d.deptId)}/></label>`}</div></div>
 <div class="card form"><div class=cardhead><h3>Change password</h3></div><div class=grid>
 <label>Current password<input type=password value=${f.cur} onInput=${set('cur')} autocomplete=current-password/></label>
 <label>New password (8+ characters)<input type=password value=${f.pw} onInput=${set('pw')} autocomplete=new-password/></label>
 <label>Confirm new password<input type=password value=${f.pw2} onInput=${set('pw2')} autocomplete=new-password/></label></div>
 <div class=formfoot><button class=ok onClick=${save}>Update password</button><span class=${bad?'err':'muted'}>${m}</span></div></div></div>`}
