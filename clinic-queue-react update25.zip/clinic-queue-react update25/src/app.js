Pages.Dashboard=Pages.Dashboard||{roles:ROLES,C:()=>html`<p>Welcome to the clinic system.</p>`};
Pages.Account={roles:ROLES,C:Account};
function App(){const[u,setU]=useState(null),[p,setP]=useState('');
 if(location.hash==='#display'&&Pages.Display)return html`<${Pages.Display.C}/>`;
 if(!u)return html`<${Login} onLogin=${setU}/>`;
 const names=Object.keys(Pages).filter(k=>Can(u.role,k)),cur=Can(u.role,p)?p:names[0],C=Pages[cur].C;
 const clinic=(DB.get('settings')[0]||{}).clinic||'Clinic Queue';
 const date=new Date().toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'});
 const item=k=>k==='Display'
  ?html`<a href="#display" target=_blank rel=noopener><${Icon} n=${k}/>${LABEL[k]}</a>`
  :html`<a class=${k===cur?'on':''} onClick=${()=>setP(k)}><${Icon} n=${k}/>${LABEL[k]||k}</a>`;
 return html`<div class=app><nav><div class=brand><span class=logo><${Icon} n=cross size=22/></span><div><b>${clinic}</b><small>Queue Management</small></div></div>
 <div class=navlist>${names.map(item)}</div>
 <div class=navfoot><a onClick=${()=>{Auth.logout();setU(null)}}><${Icon} n=logout/>Sign out</a></div></nav>
 <main><header><span class=today>${date}</span><div class=hright>${typeof Bell!=='undefined'?html`<${Bell}/>`:null}
 <div class=userchip><${Avatar} name=${u.username} size=36/><div><b>${u.username}</b><small>${ROLE_LABEL[u.role]||u.role}</small></div></div></div></header>
 <div class=page><${C}/></div></main></div>`}
Auth.init().then(()=>{DB.seed();ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`)});
