const deptName=id=>(DB.get('departments').find(d=>d.id===id)||{}).name||'';
const deptOpts=()=>DB.get('departments').filter(d=>d.active).map(d=>({v:d.id,t:d.name}));
// Rule: one active doctor per department. Returns the doctor already holding the department, if any.
const docDeptTaken=(f,all)=>(!f.id||f.active!==false)&&all.find(d=>d.id!==f.id&&d.active&&d.deptId===f.deptId);
const loginOf=id=>DB.get('users').find(u=>u.role==='doctor'&&u.doctorId===id);
Pages.Doctors={roles:['admin'],C:()=>html`<${Crud} table=doctors title="Doctors" sub="One doctor per department. Each doctor gets an individual login automatically."
 fields=${[{k:'name',label:'Full name',req:1,fmt:v=>html`<span class=person><${Avatar} name=${v}/><span>${v.replace(/^Dr\.? /,'Dr.\u00a0')}</span></span>`},{k:'spec',label:'Specialization',req:1},{k:'deptId',label:'Department',opts:deptOpts,fmt:deptName,req:1},
 {k:'avail',label:'Availability',opts:['Available','On leave','Busy'],fmt:v=>html`<${Badge} t=${v}/>`,req:1},
 {k:'phone',label:'Contact number',req:1},{k:'email',label:'Email',type:'email',req:1},{k:'days',label:'Schedule (days/hours)'}]}
 extra=${[{label:'Login',fn:x=>{const u=loginOf(x.id);return u?html`<span class=code>${u.username}</span>`:'\u2014'}}]}
 validate=${(f,all)=>{const t=docDeptTaken(f,all);return !phoneOk(f.phone)?'Enter a valid contact number':!/^\S+@\S+\.\S+$/.test(f.email)?'Enter a valid email address'
  :all.some(d=>d.id!==f.id&&(d.email||'').toLowerCase()===f.email.toLowerCase())?'This email already belongs to another doctor'
  :t?`${deptName(f.deptId)} already has a doctor (${t.name}). Deactivate that doctor first.`:''}}
 canActivate=${(x,all)=>{const t=docDeptTaken({...x,active:true},all);return t?`${deptName(x.deptId)} already has an active doctor (${t.name}). Deactivate that doctor first.`:''}}
 onChange=${()=>Auth.syncDoctors()}/>`};
Pages.Departments={roles:['admin'],C:()=>html`<${Crud} table=departments title="Departments" sub="Clinic departments and their queue-number prefixes"
 fields=${[{k:'name',label:'Department / service',req:1},{k:'code',label:'Queue code (2 letters)',fmt:v=>html`<span class=code>${v&&v.toUpperCase()}</span>`,req:1}]}
 validate=${(f,all)=>!/^[A-Za-z]{2}$/.test(f.code)?'Queue code must be 2 letters':all.some(d=>d.id!==f.id&&d.code.toUpperCase()===f.code.toUpperCase())?'Queue code already in use':''}/>`};

// Admin view of every login. Doctor accounts follow the doctor record (Doctors page); admin can reset any password.
Pages.Accounts={roles:['admin'],C(){
 const[,r]=useState(0),re=()=>r(x=>x+1),[m,setM]=useState('');
 const reset=async u=>{const p=prompt(`New password for ${u.username} (at least 8 characters):`);if(p===null)return;
  try{await Auth.setPassword(u.id,p,`Reset password for ${u.username}`);setM(`Password reset for ${u.username}.`)}catch(e){setM(e.message)}re()};
 return html`<div><${PageHead} title="Accounts" sub="Every staff member signs in with their own username. Doctor accounts follow the doctor record."/>
 ${m&&html`<p class=muted>${m}</p>`}
 <div class=tablewrap><table><thead><tr><th>Username</th><th>Role</th><th>Doctor</th><th>Department</th><th>Status</th><th></th></tr></thead><tbody>
 ${DB.get('users').map(u=>{const d=DB.get('doctors').find(x=>x.id===u.doctorId);return html`<tr class=${u.active?'':'off'}><td><span class=person><${Avatar} name=${d?d.name:u.username} size=28/>${u.username}</span></td>
 <td>${ROLE_LABEL[u.role]||u.role}</td><td>${d?d.name:'\u2014'}</td><td>${d?deptName(d.deptId):'\u2014'}</td><td><${Badge} t=${u.active?'Active':'Inactive'}/></td><td><button onClick=${()=>reset(u)}>Reset password</button></td></tr>`})}
 </tbody></table></div></div>`}};
