// Shared presentational helpers: icons, avatars, status badges, page headers.
const ICONS={
 cross:'M9 3h6v6h6v6h-6v6H9v-6H3V9h6z',
 Dashboard:'M3 3h7v9H3z|M14 3h7v5h-7z|M14 12h7v9h-7z|M3 16h7v5H3z',
 Patients:'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2|M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z|M23 21v-2a4 4 0 0 0-3-3.87|M16 3.13a4 4 0 0 1 0 7.75',
 Doctors:'M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2|M8.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z|M17 11l2 2 4-4',
 Departments:'M12 2L2 7l10 5 10-5z|M2 17l10 5 10-5|M2 12l10 5 10-5',
 Queue:'M8 6h13|M8 12h13|M8 18h13|M3 6h.01|M3 12h.01|M3 18h.01',
 Appointments:'M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z|M16 2v4|M8 2v4|M3 10h18',
 Display:'M20 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z|M8 21h8|M12 17v4',
 Reports:'M18 20V10|M12 20V4|M6 20v-6',
 Logs:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z|M14 2v6h6|M16 13H8|M16 17H8|M10 9H8',
 Settings:'M4 21v-7|M4 10V3|M12 21v-9|M12 8V3|M20 21v-5|M20 12V3|M1 14h6|M9 8h6|M17 16h6',
 Accounts:'M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.78 7.78 5.5 5.5 0 0 1 7.78-7.78zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4',
 Account:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2|M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
 logout:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4|M16 17l5-5-5-5|M21 12H9',
 bell:'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9|M13.73 21a2 2 0 0 1-3.46 0',
 clock:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z|M12 6v6l4 2',
 activity:'M22 12h-4l-3 9L9 3l-3 9H2',
 check:'M20 6L9 17l-5-5',
 userx:'M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2|M8.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z|M18 8l5 5|M23 8l-5 5',
 xcircle:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z|M15 9l-6 6|M9 9l6 6',
 search:'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z|M21 21l-4.35-4.35',
 download:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4|M7 10l5 5 5-5|M12 15V3',
 printer:'M6 9V2h12v7|M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2|M6 14h12v8H6z',
 shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
 zap:'M13 2L3 14h9l-1 8 10-12h-9z'
};
const LABEL={Dashboard:'Dashboard',Patients:'Patients',Doctors:'Doctors',Departments:'Departments',Accounts:'Accounts',Account:'My account',Queue:'Queue',Appointments:'Appointments',Display:'Live display',Reports:'Reports',Logs:'Activity logs',Settings:'Settings'};
const ROLE_LABEL={admin:'Administrator',receptionist:'Receptionist',doctor:'Doctor'};

function Icon({n,size=18}){
 return html`<svg class=icon viewBox="0 0 24 24" width=${size} height=${size} fill=none stroke=currentColor strokeWidth=2 strokeLinecap=round strokeLinejoin=round aria-hidden=true>${(ICONS[n]||'').split('|').map(d=>html`<path d=${d}/>`)}</svg>`}

const initials=n=>String(n||'?').replace(/^Dr\.?\s+/i,'').split(/\s+/).filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
const HUES=[212,172,262,24,340,142,196,48];
function Avatar({name,size=32}){
 size=+size;const hue=HUES[[...String(name)].reduce((a,c)=>a+c.charCodeAt(0),0)%HUES.length];
 return html`<span class=avatar style=${{width:size,height:size,fontSize:Math.round(size*.38),background:`hsl(${hue} 75% 93%)`,color:`hsl(${hue} 60% 30%)`}}>${initials(name)}</span>`}

const TONE={Waiting:'amber',Called:'blue','In Consultation':'violet',Completed:'green','No-Show':'red',Cancelled:'gray',Scheduled:'blue',Confirmed:'teal',
 Available:'green','On leave':'gray',Busy:'amber',Active:'green',Inactive:'gray',Regular:'gray',Senior:'amber',PWD:'blue',Pregnant:'pink'};
function Badge({t,tone}){return t?html`<span class=${'badge '+(tone||TONE[t]||'gray')}>${t}</span>`:null}

function PageHead({title,sub,children}){
 return html`<div class=pagehead><div><h2>${title}</h2>${sub&&html`<p>${sub}</p>`}</div><div class="actions noprint">${children}</div></div>`}
