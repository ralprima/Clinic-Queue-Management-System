const PRI={PWD:0,Senior:0,Pregnant:0,Regular:1},ACTIVE=['Waiting','Called','In Consultation'];
const Q={
 issue({patientId,deptId,doctorId,priority}){
  const qs=DB.get('queues'),d=today();
  if(qs.some(x=>x.patientId===patientId&&x.date===d&&ACTIVE.includes(x.status)))throw Error('Patient already has an active queue entry');
  const dept=DB.get('departments').find(x=>x.id===deptId);if(!dept)throw Error('Select a department');
  const n=qs.filter(x=>x.date===d&&x.deptId===deptId).length+1,no=dept.code.toUpperCase()+'-'+String(n).padStart(3,'0');
  const r=DB.add('queues',{no,patientId,deptId,doctorId,priority:priority||'Regular',date:d,status:'Waiting',created:Date.now(),at:Date.now()});
  DB.log(`Queue ${no} issued`);return r},
 waiting:deptId=>DB.get('queues').filter(x=>x.date===today()&&x.status==='Waiting'&&(!deptId||x.deptId===deptId)).sort((a,b)=>PRI[a.priority]-PRI[b.priority]||a.at-b.at)
};
const pName=id=>{const p=DB.get('patients').find(x=>x.id===id);return p?p.last+', '+p.first:''};
Pages.Queue={roles:ROLES,C(){
 const[,r]=useState(0),re=()=>r(x=>x+1),[f,setF]=useState({priority:'Regular'}),[err,setErr]=useState(''),[hist,setHist]=useState(false);
 const u=Auth.user,doc=u.role==='doctor',run=fn=>()=>{try{fn();setErr('')}catch(e){setErr(e.message)}re()};
 const rows=DB.get('queues').filter(x=>(hist||x.date===today())&&(!doc||x.doctorId===u.doctorId)).sort((a,b)=>b.created-a.created);
 const btn=(t,cls,fn)=>html`<button class=${cls} onClick=${run(fn)}>${t}</button> `;
 return html`<div><h2>Queue</h2>${!doc&&html`<div class=card><label>Patient<select onChange=${e=>setF({...f,patientId:e.target.value})}><option value="">Select…</option>${DB.get('patients').filter(p=>p.active).map(p=>html`<option value=${p.id}>${pName(p.id)}</option>`)}</select></label>
 <label>Department<select onChange=${e=>setF({...f,deptId:e.target.value})}><option value="">Select…</option>${deptOpts().map(o=>html`<option value=${o.v}>${o.t}</option>`)}</select></label>
 <label>Doctor<select onChange=${e=>setF({...f,doctorId:e.target.value})}><option value="">Select…</option>${DB.get('doctors').filter(d=>d.active&&d.deptId===f.deptId).map(d=>html`<option value=${d.id}>${d.name}</option>`)}</select></label>
 <label>Priority<select onChange=${e=>setF({...f,priority:e.target.value})}>${Object.keys(PRI).map(p=>html`<option>${p}</option>`)}</select></label>
 ${btn('Issue queue number','ok',()=>{if(!f.patientId)throw Error('Select a patient');Q.issue(f)})}<span class=err>${err}</span></div>`}
 <h3>Waiting list (${Q.waiting().length})</h3><p>${Q.waiting().map(w=>w.no+(w.priority==='Regular'?'':' ★')).join(', ')||'Nobody is waiting.'}</p>
 <label><input type=checkbox checked=${hist} onChange=${e=>setHist(e.target.checked)}/> Show queue history</label>
 <table><tr><th>No.</th><th>Date</th><th>Patient</th><th>Priority</th><th>Status</th></tr>${rows.map(x=>html`<tr><td>${x.no}</td><td>${x.date}</td><td>${pName(x.patientId)}</td><td>${x.priority}</td><td>${x.status}</td></tr>`)}</table></div>`}};
