const Appt={conflict:(a,all)=>all.some(x=>x.id!==a.id&&x.doctorId===a.doctorId&&x.date===a.date&&x.time===a.time&&x.status!=='Cancelled')};
Pages.Appointments={roles:['admin','receptionist'],C:()=>html`<${Crud} table=appointments title="Appointments"
 fields=${[{k:'patientId',label:'Patient',opts:()=>DB.get('patients').filter(p=>p.active).map(p=>({v:p.id,t:pName(p.id)})),fmt:pName,req:1},
 {k:'doctorId',label:'Doctor',opts:()=>DB.get('doctors').filter(d=>d.active).map(d=>({v:d.id,t:d.name})),fmt:v=>(DB.get('doctors').find(d=>d.id===v)||{}).name,req:1},
 {k:'deptId',label:'Department',opts:deptOpts,fmt:deptName,req:1},{k:'date',label:'Date',type:'date',req:1},{k:'time',label:'Time',type:'time',req:1},
 {k:'status',label:'Status',opts:['Scheduled','Confirmed','Completed','Cancelled','No-Show'],req:1}]}
 validate=${(f,all)=>f.date<today()&&!f.id?'Appointment date cannot be in the past':Appt.conflict(f,all)?'This doctor already has an appointment at that time':''}
 actions=${(x,re)=>['Scheduled','Confirmed'].includes(x.status)&&x.date===today()?html`<button class=ok onClick=${()=>{try{Q.issue({...x,priority:'Regular'});DB.upd('appointments',x.id,{status:'Completed'});re()}catch(e){alert(e.message)}}}>Patient arrived</button>`:null}/>`};
