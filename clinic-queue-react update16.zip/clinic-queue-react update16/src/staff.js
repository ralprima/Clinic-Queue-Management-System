const deptName=id=>(DB.get('departments').find(d=>d.id===id)||{}).name||'';
const deptOpts=()=>DB.get('departments').filter(d=>d.active).map(d=>({v:d.id,t:d.name}));
Pages.Doctors={roles:['admin'],C:()=>html`<${Crud} table=doctors title="Doctors and schedules"
 fields=${[{k:'name',label:'Full name',req:1},{k:'spec',label:'Specialization',req:1},{k:'deptId',label:'Department',opts:deptOpts,fmt:deptName,req:1},
 {k:'phone',label:'Contact number',req:1},{k:'email',label:'Email',type:'email',req:1},{k:'days',label:'Schedule (days/hours)'},{k:'avail',label:'Availability',opts:['Available','On leave','Busy'],req:1}]}
 validate=${f=>!phoneOk(f.phone)?'Enter a valid contact number':!/^\S+@\S+\.\S+$/.test(f.email)?'Enter a valid email address':''}/>`};
Pages.Departments={roles:['admin'],C:()=>html`<${Crud} table=departments title="Departments and services"
 fields=${[{k:'name',label:'Department / service',req:1},{k:'code',label:'Queue code (2 letters)',req:1}]}
 validate=${(f,all)=>!/^[A-Za-z]{2}$/.test(f.code)?'Queue code must be 2 letters':all.some(d=>d.id!==f.id&&d.code.toUpperCase()===f.code.toUpperCase())?'Queue code already in use':''}/>`};
