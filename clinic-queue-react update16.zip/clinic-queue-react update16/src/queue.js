const PRI={PWD:0,Senior:0,Pregnant:0,Regular:1},ACTIVE=['Waiting','Called','In Consultation'];
const Q={
 issue({patientId,deptId,doctorId,priority}){
  const qs=DB.get('queues'),d=today();
  if(qs.some(x=>x.patientId===patientId&&x.date===d&&ACTIVE.includes(x.status)))throw Error('Patient already has an active queue entry');
  const dept=DB.get('departments').find(x=>x.id===deptId);if(!dept)throw Error('Select a department');
  const n=qs.filter(x=>x.date===d&&x.deptId===deptId).length+1,no=dept.code.toUpperCase()+'-'+String(n).padStart(3,'0');
  const r=DB.add('queues',{no,patientId,deptId,doctorId,priority:priority||'Regular',date:d,status:'Waiting',created:Date.now(),at:Date.now()});
  DB.log(`Queue ${no} issued`);return r},
 waiting:deptId=>DB.get('queues').filter(x=>x.date===today()&&x.status==='Waiting'&&(!deptId||x.deptId===deptId)).sort((a,b)=>PRI[a.priority]-PRI[b.priority]||a.at-b.at),
 set(id,status,extra={}){const r=DB.get('queues').find(x=>x.id===id);DB.upd('queues',id,{status,...extra});DB.log(`Queue ${r.no} ${status}`)},
 callNext(deptId){const n=Q.waiting(deptId)[0];if(!n)throw Error('No waiting patients');Q.set(n.id,'Called',{calledAt:Date.now()});return n},
 skip(id){const r=DB.get('queues').find(x=>x.id===id);DB.upd('queues',id,{status:'Waiting',at:Date.now()});DB.log(`Queue ${r.no} skipped`)}
};
const pName=id=>{const p=DB.get('patients').find(x=>x.id===id);return p?p.last+', '+p.first:''};
Pages.Queue={roles:ROLES,C(){
 const[,r]=useState(0),re=()=>r(x=>x+1),[f,setF]=useState({priority:'Regular'}),[err,setErr]=useState(''),[hist,setHist]=useState(false);
 const u=Auth.user,doc=u.role==='doctor',run=fn=>()=>{try{fn();setErr('')}catch(e){setErr(e.message)}re()};
 const rows=DB.get('queues').filter(x=>(hist||x.date===today())&&(!doc||x.doctorId===u.doctorId)).sort((a,b)=>b.created-a.created);
 const btn=(t,cls,fn)=>html`<button class=${cls} onClick=${run(fn)}>${t}</button> `;
 const act=x=>({Waiting:[['Cancel','bad',()=>Q.set(x.id,'Cancelled')]],Called:[['Recall','warn',()=>Q.set(x.id,'Called',{calledAt:Date.now()})],['Skip','warn',()=>Q.skip(x.id)],
  ['Start','ok',()=>Q.set(x.id,'In Consultation')],['No-show','bad',()=>Q.set(x.id,'No-Show')]],'In Consultation':[['Complete','ok',()=>Q.set(x.id,'Completed',{doneAt:Date.now()})]]}[x.status]||[]).map(a=>btn(...a));
 return html`<div><h2>Queue</h2>${!doc&&html`<div class=card><label>Patient<select onChange=${e=>setF({...f,patientId:e.target.value})}><option value="">Select…</option>${DB.get('patients').filter(p=>p.active).map(p=>html`<option value=${p.id}>${pName(p.id)}</option>`)}</select></label>
 <label>Department<select onChange=${e=>setF({...f,deptId:e.target.value})}><option value="">Select…</option>${deptOpts().map(o=>html`<option value=${o.v}>${o.t}</option>`)}</select></label>
 <label>Doctor<select onChange=${e=>setF({...f,doctorId:e.target.value})}><option value="">Select…</option>${DB.get('doctors').filter(d=>d.active&&d.deptId===f.deptId).map(d=>html`<option value=${d.id}>${d.name}</option>`)}</select></label>
 <label>Priority<select onChange=${e=>setF({...f,priority:e.target.value})}>${Object.keys(PRI).map(p=>html`<option>${p}</option>`)}</select></label>
 ${btn('Issue queue number','ok',()=>{if(!f.patientId)throw Error('Select a patient');Q.issue(f)})}</div>`}
 <div class=card>${deptOpts().map(o=>btn('Call next: '+o.t,'',()=>Q.callNext(o.v)))}<span class=err>${err}</span></div>
 <h3>Waiting list (${Q.waiting().length})</h3><p>${Q.waiting().map(w=>w.no+(w.priority==='Regular'?'':' ★')).join(', ')||'Nobody is waiting.'}</p>
 <label><input type=checkbox checked=${hist} onChange=${e=>setHist(e.target.checked)}/> Show queue history</label>
 <table><tr><th>No.</th><th>Date</th><th>Patient</th><th>Priority</th><th>Status</th><th></th></tr>${rows.map(x=>html`<tr><td>${x.no}</td><td>${x.date}</td><td>${pName(x.patientId)}</td><td>${x.priority}</td><td>${x.status}</td><td>${act(x)}</td></tr>`)}</table></div>`}};
