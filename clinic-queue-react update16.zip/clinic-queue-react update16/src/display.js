// Public display: queue numbers only, no patient names. Open index.html#display on the TV.
Pages.Display={roles:ROLES,C(){
 const[,r]=useState(0);useEffect(()=>{const t=setInterval(()=>r(x=>x+1),2000);return()=>clearInterval(t)},[]);
 const now=DB.get('queues').filter(x=>x.date===today()&&['Called','In Consultation'].includes(x.status)).sort((a,b)=>(b.calledAt||0)-(a.calledAt||0));
 const dn=id=>(DB.get('doctors').find(d=>d.id===id)||{}).name||'';
 return html`<div class=tv><h1>Now serving</h1>${now.length?now.map((x,i)=>html`<div class=${i?'':'hot'}><span class=big>${x.no}</span> ${deptName(x.deptId)} · ${dn(x.doctorId)} · ${x.status}</div>`):html`<p>No patient is being called.</p>`}
 <h2>Next in line</h2><p class=big style=${{fontSize:36}}>${Q.waiting().slice(0,6).map(w=>w.no).join('   ')||'—'}</p></div>`}};
