// Notifications are raised from queue/appointment events by hooking the activity log.
const _log=DB.log;
DB.log=a=>{_log(a);if(/queue|appointments/i.test(a))DB.add('notifications',{msg:a,at:Date.now(),read:false})};
function Bell(){const[,r]=useState(0),[open,setOpen]=useState(false);useEffect(()=>{const t=setInterval(()=>r(x=>x+1),2000);return()=>clearInterval(t)},[]);
 const ns=DB.get('notifications').slice(-8).reverse(),un=ns.filter(n=>!n.read).length;
 return html`<span style=${{position:'relative'}}><button onClick=${()=>{setOpen(!open);DB.set('notifications',DB.get('notifications').map(n=>({...n,read:true})))}}>Alerts${un?` (${un})`:''}</button>
 ${open&&html`<div class=card style=${{position:'absolute',right:0,width:280,zIndex:5,flexDirection:'column',align:'start'}}>${ns.map(n=>html`<small>${new Date(n.at).toLocaleTimeString()} ${n.msg}</small>`)||'Nothing new'}</div>`}</span>`}
