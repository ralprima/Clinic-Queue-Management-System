const dl=(name,text,type)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click()};
Pages.Reports={roles:['admin'],C(){
 const[per,setPer]=useState(1),[q,setQ]=useState(''),from=new Date(Date.now()-(per-1)*864e5).toISOString().slice(0,10);
 const rows=DB.get('queues').filter(x=>x.date>=from&&JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
 const waits=rows.filter(x=>x.calledAt).map(x=>(x.calledAt-x.created)/6e4),avg=waits.length?(waits.reduce((a,b)=>a+b,0)/waits.length).toFixed(1):'n/a';
 const cnt=s=>rows.filter(x=>x.status===s).length;
 const csv=()=>dl('queue-report.csv',['Queue,Date,Department,Priority,Status',...rows.map(x=>[x.no,x.date,deptName(x.deptId),x.priority,x.status].join(','))].join('\n'),'text/csv');
 return html`<div><h2>Reports</h2><div class=card><label>Period<select value=${per} onChange=${e=>setPer(+e.target.value)}><option value=1>Daily</option><option value=7>Weekly</option><option value=30>Monthly</option></select></label>
 <label>Search<input value=${q} onInput=${e=>setQ(e.target.value)}/></label><button onClick=${csv}>Export Excel (CSV)</button><button onClick=${()=>print()}>Print / Save as PDF</button></div>
 <p>Total ${rows.length} · Completed ${cnt('Completed')} · No-show ${cnt('No-Show')} · Cancelled ${cnt('Cancelled')} · Average wait ${avg} min</p>
 <table><tr><th>No.</th><th>Date</th><th>Department</th><th>Priority</th><th>Status</th></tr>${rows.map(x=>html`<tr><td>${x.no}</td><td>${x.date}</td><td>${deptName(x.deptId)}</td><td>${x.priority}</td><td>${x.status}</td></tr>`)}</table></div>`}};
Pages.Logs={roles:['admin'],C:()=>html`<div><h2>Activity logs</h2><table><tr><th>When</th><th>User</th><th>Activity</th></tr>${DB.get('activity_logs').slice(-200).reverse().map(l=>html`<tr><td>${new Date(l.at).toLocaleString()}</td><td>${l.user}</td><td>${l.action}</td></tr>`)}</table></div>`};
Pages.Settings={roles:['admin'],C(){
 const[n,setN]=useState((DB.get('settings')[0]||{}).clinic||''),[m,setM]=useState('');
 const backup=()=>dl('clinic-backup.json',JSON.stringify(Object.fromEntries(TABLES.map(t=>[t,DB.get(t)]))),'application/json');
 const restore=e=>{const fr=new FileReader();fr.onload=()=>{try{const d=JSON.parse(fr.result);TABLES.forEach(t=>d[t]&&DB.set(t,d[t]));DB.log('Database restored');setM('Restored. Reload the page.')}catch{setM('That file is not a valid backup.')}};fr.readAsText(e.target.files[0])};
 return html`<div><h2>Settings</h2><div class=card><label>Clinic name<input value=${n} onInput=${e=>setN(e.target.value)}/></label>
 <button class=ok onClick=${()=>{DB.set('settings',[{id:'cfg',clinic:n}]);DB.log('Updated settings');setM('Saved. Reload to see the new name.')}}>Save settings</button></div>
 <div class=card><button onClick=${backup}>Back up database</button><label>Restore from backup<input type=file accept=.json onChange=${restore}/></label><span>${m}</span></div></div>`}};
