function App(){return html`<div style=${{padding:20}}><h1>Clinic Queue Management System</h1><p>Storage ready: ${TABLES.length} tables.</p></div>`}
ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`);
