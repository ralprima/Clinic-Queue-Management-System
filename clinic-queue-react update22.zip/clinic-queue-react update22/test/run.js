// Logic tests: loads the real source files in a sandbox with a fake localStorage.
const vm=require('vm'),fs=require('fs'),assert=require('assert');
const store={},ctx=vm.createContext({localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)},crypto:globalThis.crypto,TextEncoder,
 React:{useState:()=>[0,()=>{}],useEffect(){},createElement:()=>null},htm:{bind:()=>()=>null},document:{},location:{hash:''},URL,Blob,setInterval(){}});
for(const f of['db','ui','auth','crud','patients','staff','queue','appointments','display','notify','reports'])vm.runInContext(fs.readFileSync(`src/${f}.js`,'utf8'),ctx,{filename:f});
const R=s=>vm.runInContext(s,ctx);let n=0;const t=async(name,fn)=>{await fn();console.log('✓',name);n++};
(async()=>{
 await R('Auth.init()');
 await t('seeded departments, doctors, users',()=>{assert.equal(R('DB.get("departments").length'),4);assert.equal(R('DB.get("users").length'),3)});
 await t('doctor roster covers every department with unique emails',()=>{const ds=R('DB.get("doctors")');assert(ds.length>=12);assert.equal(new Set(ds.map(d=>d.email)).size,ds.length);
  for(const d of R('DB.get("departments")'))assert(ds.filter(x=>x.deptId===d.id).length>=2,'no doctors for '+d.name)});
 await t('roster is added once to an existing install without duplicates',()=>{R('DB.set("doctors",DB.get("doctors").slice(0,2))');delete store.cq_roster;R('DB.seed()');assert.equal(R('DB.get("doctors").length'),12);R('DB.seed()');assert.equal(R('DB.get("doctors").length'),12)});
 await t('login succeeds and rejects bad password',async()=>{assert.equal((await R('Auth.login("admin","Passw0rd!")')).role,'admin');await assert.rejects(R('Auth.login("admin","x")'))});
 await t('passwords are stored hashed',()=>assert(!R('JSON.stringify(DB.get("users"))').includes('Passw0rd!')));
 await t('role permissions',()=>{assert(R('Can("admin","Reports")'));assert(!R('Can("doctor","Reports")'));assert(!R('Can("receptionist","Doctors")'));assert(R('Can("doctor","Queue")'))});
 R('["a","b","c"].forEach(x=>DB.add("patients",{first:x,last:"T",dob:"1990-01-01",active:true}))');
 const [a,b,c]=R('DB.get("patients").map(p=>p.id)'),dept=R('DB.get("departments")[0].id');
 await t('queue numbers are sequential per department/day',()=>{R(`Q.issue({patientId:"${a}",deptId:"${dept}"})`);assert.equal(R(`Q.issue({patientId:"${b}",deptId:"${dept}"}).no`),'GC-002')});
 await t('duplicate active entry is blocked',()=>assert.throws(()=>R(`Q.issue({patientId:"${a}",deptId:"${dept}"})`),/active queue/));
 await t('priority patients are called first',()=>{R(`Q.issue({patientId:"${c}",deptId:"${dept}",priority:"Senior"})`);assert.equal(R('Q.callNext().no'),'GC-003')});
 await t('skip moves patient to back; cancel removes from waiting',()=>{const id=R('Q.waiting()[0].id');R(`Q.skip("${id}")`);assert.equal(R('Q.waiting().length'),2);R(`Q.set("${id}","Cancelled")`);assert.equal(R('Q.waiting().length'),1)});
 await t('appointment conflicts detected',()=>{const x={id:'1',doctorId:'d',date:'2030-01-01',time:'09:00',status:'Scheduled'};assert(R(`Appt.conflict({id:'2',doctorId:'d',date:'2030-01-01',time:'09:00'},[${JSON.stringify(x)}])`));assert(!R(`Appt.conflict({id:'2',doctorId:'d',date:'2030-01-01',time:'10:00'},[${JSON.stringify(x)}])`))});
 await t('events create notifications and logs',()=>{assert(R('DB.get("notifications").length')>0);assert(R('DB.get("activity_logs").length')>0)});
 console.log(n+' tests passed');
})().catch(e=>{console.error('✗',e.message);process.exit(1)});
