// Data layer: tables persisted in localStorage (stand-in for MySQL clinic_queue_db).
const html=htm.bind(React.createElement),{useState,useEffect}=React;
const TABLES=['users','patients','doctors','departments','appointments','queues','notifications','activity_logs','settings'];
const today=()=>new Date().toISOString().slice(0,10);
// Doctor roster seeded on first run (and added once to existing installs). Matched by email, never duplicated.
const ROSTER=[
 ['Dr. Miguel Reyes','General Medicine','GC','09170000001','reyes@clinic.ph','Available','Mon-Fri 9-17'],
 ['Dr. Ana Santos','Pediatrics','PD','09170000002','santos@clinic.ph','Available','Mon-Sat 8-12'],
 ['Dr. Carla Mendoza','Family Medicine','GC','09170000003','mendoza@clinic.ph','Available','Mon-Fri 8-16'],
 ['Dr. Joseph Villanueva','Internal Medicine','GC','09170000004','villanueva@clinic.ph','Busy','Tue-Sat 10-18'],
 ['Dr. Patricia Lim','Geriatrics','GC','09170000005','lim@clinic.ph','Available','Mon, Wed, Fri 9-15'],
 ['Dr. Rafael Bautista','General Dentistry','DN','09170000006','bautista@clinic.ph','Available','Mon-Fri 9-17'],
 ['Dr. Sofia Aquino','Orthodontics','DN','09170000007','aquino@clinic.ph','Available','Tue-Sat 10-18'],
 ['Dr. Marco Dela Cruz','Oral Surgery','DN','09170000008','delacruz@clinic.ph','On leave','Mon, Thu 13-17'],
 ['Dr. Isabel Garcia','Neonatology','PD','09170000009','garcia@clinic.ph','Available','Mon-Fri 8-14'],
 ['Dr. Daniel Ramos','Developmental Pediatrics','PD','09170000010','ramos@clinic.ph','Available','Tue-Thu 9-15'],
 ['Dr. Camille Torres','Clinical Pathology','LB','09170000011','torres@clinic.ph','Available','Mon-Sat 7-15'],
 ['Dr. Benedict Ocampo','Hematology','LB','09170000012','ocampo@clinic.ph','Busy','Mon-Fri 8-16']];
const DB={
 get:t=>JSON.parse(localStorage.getItem('cq_'+t)||'[]'),
 set:(t,v)=>localStorage.setItem('cq_'+t,JSON.stringify(v)),
 add(t,r){r={id:'i'+Math.random().toString(36).slice(2,10),...r};DB.set(t,[...DB.get(t),r]);return r},
 upd:(t,id,p)=>DB.set(t,DB.get(t).map(r=>r.id===id?{...r,...p}:r)),
 log(a){DB.add('activity_logs',{user:(typeof Auth!=='undefined'&&Auth.user||{}).username||'system',action:a,at:Date.now()})},
 seed(){if(!DB.get('departments').length)
  ['General Consultation:GC','Dental:DN','Pediatrics:PD','Laboratory:LB'].forEach(s=>{const[name,code]=s.split(':');DB.add('departments',{name,code,active:true})});
  if(localStorage.getItem('cq_roster')!=='1'){const ds=DB.get('departments'),have=DB.get('doctors').map(d=>d.email);
   for(const[name,spec,code,phone,email,avail,days]of ROSTER){const d=ds.find(x=>x.code===code);if(d&&!have.includes(email))DB.add('doctors',{name,spec,deptId:d.id,phone,email,avail,days,active:true})}
   localStorage.setItem('cq_roster','1')}}
};
