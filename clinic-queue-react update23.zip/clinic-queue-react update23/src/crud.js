// Reusable table + form with validation, search, edit and (de)activation.
function Crud({table,title,sub,fields,validate,extra=[],actions,canAdd=true,canActivate}){
 const[,r]=useState(0),re=()=>r(x=>x+1),[f,setF]=useState({}),[q,setQ]=useState(''),[err,setErr]=useState('');
 const rows=DB.get(table).filter(x=>JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
 const set=k=>e=>setF({...f,[k]:e.target.value});
 const save=()=>{Object.keys(f).forEach(k=>typeof f[k]==='string'&&(f[k]=f[k].trim()));const m=fields.find(d=>d.req&&!String(f[d.k]||'').trim());if(m)return setErr(m.label+' is required');
  const v=validate&&validate(f,DB.get(table));if(v)return setErr(v);
  f.id?DB.upd(table,f.id,f):DB.add(table,{active:true,created:today(),...f});DB.log(`${f.id?'Updated':'Added'} ${table}`);setF({});setErr('');re()};
 const opts=d=>(typeof d.opts==='function'?d.opts():d.opts).map(o=>html`<option value=${o.v??o}>${o.t??o}</option>`);
 return html`<div><${PageHead} title=${title} sub=${sub}/>${canAdd&&html`<div class="card form"><div class=cardhead><h3>${f.id?'Edit record':'Add new'}</h3>${f.id&&html`<span class=hint>Editing — changes apply when you save</span>`}</div>
  <div class=grid>${fields.map(d=>html`<label><span>${d.label}${d.req?html`<i class=req>*</i>`:null}</span>${d.opts
  ?html`<select value=${f[d.k]||''} onChange=${set(d.k)}><option value="">Select…</option>${opts(d)}</select>`
  :html`<input type=${d.type||'text'} value=${f[d.k]||''} onInput=${set(d.k)}/>`}</label>`)}</div>
  <div class=formfoot><button class=ok onClick=${save}>${f.id?'Save changes':'Add'}</button>${f.id&&html`<button class=ghost onClick=${()=>setF({})}>Cancel edit</button>`}<span class=err>${err}</span></div></div>`}
 <div class=toolbar><label class=search><${Icon} n=search size=16/><input placeholder="Search ${title.toLowerCase()}…" value=${q} onInput=${e=>setQ(e.target.value)}/></label><span class=count>${rows.length} ${rows.length===1?'record':'records'}</span></div>
 <div class=tablewrap><table><thead><tr>${fields.map(d=>html`<th>${d.label}</th>`)}${extra.map(x=>html`<th>${x.label}</th>`)}<th></th></tr></thead>
 <tbody>${rows.length?rows.map(x=>html`<tr class=${x.active?'':'off'}>${fields.map((d,i)=>html`<td>${d.fmt?d.fmt(x[d.k],x):x[d.k]}${!i&&!x.active?html` <${Badge} t="Inactive"/>`:null}</td>`)}${extra.map(e=>html`<td>${e.fn(x)}</td>`)}
 <td><button onClick=${()=>{setF(x);scrollTo(0,0)}}>Edit</button><button class=${x.active?'bad':'ok'} onClick=${()=>{if(!x.active&&canActivate){const m=canActivate(x,DB.get(table));if(m){setErr(m);scrollTo(0,0);return}}setErr('');DB.upd(table,x.id,{active:!x.active});DB.log(`${x.active?'Deactivated':'Activated'} ${table}`);re()}}>${x.active?'Deactivate':'Activate'}</button>
 ${actions&&actions(x,re)}</td></tr>`):html`<tr><td class=empty colspan=20>No records yet. Add one above.</td></tr>`}</tbody></table></div></div>`}
