const deptName=id=>(DB.get('departments').find(d=>d.id===id)||{}).name||'';
const deptOpts=()=>DB.get('departments').filter(d=>d.active).map(d=>({v:d.id,t:d.name}));
// Rule: one active doctor per department. Returns the doctor already holding the department, if any.
const docDeptTaken=(f,all)=>(!f.id||f.active!==false)&&all.find(d=>d.id!==f.id&&d.active&&d.deptId===f.deptId);
Pages.Doctors={roles:['admin'],C:()=>html`<${Crud} table=doctors title="Doctors" sub="One doctor per department: profiles, specializations and weekly schedules"
 fields=${[{k:'name',label:'Full name',req:1,fmt:v=>html`<span class=person><${Avatar} name=${v}/><span>${v.replace(/^Dr\.? /,'Dr.\u00a0')}</span></span>`},{k:'spec',label:'Specialization',req:1},{k:'deptId',label:'Department',opts:deptOpts,fmt:deptName,req:1},
 {k:'avail',label:'Availability',opts:['Available','On leave','Busy'],fmt:v=>html`<${Badge} t=${v}/>`,req:1},
 {k:'phone',label:'Contact number',req:1},{k:'email',label:'Email',type:'email',req:1},{k:'days',label:'Schedule (days/hours)'}]}
 validate=${(f,all)=>{const t=docDeptTaken(f,all);return !phoneOk(f.phone)?'Enter a valid contact number':!/^\S+@\S+\.\S+$/.test(f.email)?'Enter a valid email address'
  :all.some(d=>d.id!==f.id&&(d.email||'').toLowerCase()===f.email.toLowerCase())?'This email already belongs to another doctor'
  :t?`${deptName(f.deptId)} already has a doctor (${t.name}). Deactivate that doctor first.`:''}}
 canActivate=${(x,all)=>{const t=docDeptTaken({...x,active:true},all);return t?`${deptName(x.deptId)} already has an active doctor (${t.name}). Deactivate that doctor first.`:''}}
/>`};
Pages.Departments={roles:['admin'],C:()=>html`<${Crud} table=departments title="Departments" sub="Clinic departments and their queue-number prefixes"
 fields=${[{k:'name',label:'Department / service',req:1},{k:'code',label:'Queue code (2 letters)',fmt:v=>html`<span class=code>${v&&v.toUpperCase()}</span>`,req:1}]}
 validate=${(f,all)=>!/^[A-Za-z]{2}$/.test(f.code)?'Queue code must be 2 letters':all.some(d=>d.id!==f.id&&d.code.toUpperCase()===f.code.toUpperCase())?'Queue code already in use':''}/>`};

