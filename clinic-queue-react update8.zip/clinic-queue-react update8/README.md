# Clinic Queue Management (React)

Runs as static files: open `index.html` (or `npx serve .`) in Chrome/Edge. React and htm load from CDN, so the first run needs internet.

**Demo logins** (password `Passw0rd!`): `admin`, `reception`, `doctor`.
