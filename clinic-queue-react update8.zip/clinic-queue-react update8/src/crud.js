// Reusable table + form with validation, search, edit and (de)activation.
function Crud({table,title,fields,validate,extra=[],actions,canAdd=true}){
 const[,r]=useState(0),re=()=>r(x=>x+1),[f,setF]=useState({}),[q,setQ]=useState(''),[err,setErr]=useState('');
 const rows=DB.get(table).filter(x=>JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
 const set=k=>e=>setF({...f,[k]:e.target.value});
 const save=()=>{const m=fields.find(d=>d.req&&!String(f[d.k]||'').trim());if(m)return setErr(m.label+' is required');
  const v=validate&&validate(f,DB.get(table));if(v)return setErr(v);
  f.id?DB.upd(table,f.id,f):DB.add(table,{active:true,created:today(),...f});DB.log(`${f.id?'Updated':'Added'} ${table}`);setF({});setErr('');re()};
 const opts=d=>(typeof d.opts==='function'?d.opts():d.opts).map(o=>html`<option value=${o.v??o}>${o.t??o}</option>`);
 return html`<div><h2>${title}</h2>${canAdd&&html`<div class=card>${fields.map(d=>html`<label>${d.label}${d.opts
  ?html`<select value=${f[d.k]||''} onChange=${set(d.k)}><option value="">Select…</option>${opts(d)}</select>`
  :html`<input type=${d.type||'text'} value=${f[d.k]||''} onInput=${set(d.k)}/>`}</label>`)}
  <button class=ok onClick=${save}>${f.id?'Save changes':'Add'}</button>${f.id&&html`<button onClick=${()=>setF({})}>Cancel edit</button>`}<span class=err>${err}</span></div>`}
 <label>Search<input value=${q} onInput=${e=>setQ(e.target.value)}/></label>
 <table><tr>${fields.map(d=>html`<th>${d.label}</th>`)}${extra.map(x=>html`<th>${x.label}</th>`)}<th>Status</th><th></th></tr>
 ${rows.length?rows.map(x=>html`<tr>${fields.map(d=>html`<td>${d.fmt?d.fmt(x[d.k],x):x[d.k]}</td>`)}${extra.map(e=>html`<td>${e.fn(x)}</td>`)}<td>${x.active?'Active':'Inactive'}</td>
 <td><button onClick=${()=>{setF(x);scrollTo(0,0)}}>Edit</button> <button class=${x.active?'bad':'ok'} onClick=${()=>{DB.upd(table,x.id,{active:!x.active});DB.log(`${x.active?'Deactivated':'Activated'} ${table}`);re()}}>${x.active?'Deactivate':'Activate'}</button>
 ${actions&&actions(x,re)}</td></tr>`):html`<tr><td colspan=20>No records yet. Add one above.</td></tr>`}</table></div>`}
