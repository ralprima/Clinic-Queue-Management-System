Pages.Dashboard={roles:ROLES,C(){
 const u=Auth.user,mine=r=>u.role!=='doctor'||r.doctorId===u.doctorId;
 const q=DB.get('queues').filter(r=>r.date===today()&&mine(r)),ap=DB.get('appointments').filter(a=>a.date===today()&&mine(a));
 const n=s=>q.filter(r=>s.includes(r.status)).length;
 const cards=[['Registered patients',DB.get('patients').length,['admin','receptionist']],['Patients today',q.length],['Waiting',n(['Waiting'])],
  ['Being served',n(['Called','In Consultation'])],['Completed',n(['Completed'])],['No-show',n(['No-Show'])],['Appointments today',ap.length],
  ['Cancelled appointments',DB.get('appointments').filter(a=>a.status==='Cancelled').length,['admin','receptionist']],
  ['Available doctors',DB.get('doctors').filter(d=>d.active&&d.avail==='Available').length,['admin','receptionist']]].filter(c=>!c[2]||c[2].includes(u.role));
 const st=['Waiting','Called','In Consultation','Completed','No-Show','Cancelled'],mx=Math.max(1,...st.map(s=>n([s])));
 return html`<div><h2>Dashboard</h2><div class=stats>${cards.map(c=>html`<div class=stat>${c[0]}<b>${c[1]}</b></div>`)}</div>
 <h3>Today's queue by status</h3>${st.map(s=>html`<div class=bar style=${{width:(10+n([s])/mx*90)+'%'}}>${s}: ${n([s])}</div>`)}</div>`}};
