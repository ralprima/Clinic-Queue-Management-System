Pages.Patients={roles:['admin','receptionist'],C:()=>html`<${Crud} table=patients title="Patients"
 fields=${[{k:'first',label:'First name',req:1},{k:'mid',label:'Middle name'},{k:'last',label:'Last name',req:1},{k:'dob',label:'Date of birth',type:'date',req:1},
 {k:'gender',label:'Gender',opts:['Female','Male','Other'],req:1},{k:'phone',label:'Contact number',req:1},{k:'address',label:'Address'}]}/>`};
