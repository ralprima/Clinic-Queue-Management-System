Pages.Dashboard=Pages.Dashboard||{roles:ROLES,C:()=>html`<p>Welcome to the clinic system.</p>`};
function App(){const[u,setU]=useState(null),[p,setP]=useState('');
 if(!u)return html`<${Login} onLogin=${setU}/>`;
 const names=Object.keys(Pages).filter(k=>Can(u.role,k)),cur=Can(u.role,p)?p:names[0],C=Pages[cur].C;
 const clinic=(DB.get('settings')[0]||{}).clinic||'Clinic Queue';
 return html`<div class=app><nav><h3>${clinic}</h3>${names.map(k=>html`<a class=${k===cur?'on':''} onClick=${()=>setP(k)}>${k}</a>`)}
 <a onClick=${()=>{Auth.logout();setU(null)}}>Logout</a></nav><main><header>${typeof Bell!=='undefined'?html`<${Bell}/>`:null}<span>${u.username} (${u.role})</span></header><${C}/></main></div>`}
Auth.init().then(()=>{DB.seed();ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`)});
