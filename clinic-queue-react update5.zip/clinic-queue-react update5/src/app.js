function App(){const[u,setU]=useState(null);
 if(!u)return html`<${Login} onLogin=${setU}/>`;
 return html`<div style=${{padding:20}}><h1>Welcome, ${u.username}</h1><p>Signed in as ${u.role}.</p><button onClick=${()=>{Auth.logout();setU(null)}}>Logout</button></div>`}
Auth.init().then(()=>{DB.seed();ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`)});
