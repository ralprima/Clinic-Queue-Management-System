DB.seed();
function App(){return html`<div style=${{padding:20}}><h1>Clinic Queue Management System</h1><p>Storage ready: ${TABLES.length} tables · ${DB.get('departments').length} departments · ${DB.get('doctors').length} doctors seeded.</p></div>`}
ReactDOM.createRoot(document.getElementById('root')).render(html`<${App}/>`);
