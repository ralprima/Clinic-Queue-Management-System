Pages.Dashboard={roles:ROLES,C(){
 const u=Auth.user,mine=r=>u.role!=='doctor'||r.doctorId===u.doctorId,staff=['admin','receptionist'].includes(u.role);
 const q=DB.get('queues').filter(r=>r.date===today()&&mine(r)),ap=DB.get('appointments').filter(a=>a.date===today()&&mine(a));
 const n=s=>q.filter(r=>s.includes(r.status)).length;
 const cards=[['Registered patients',DB.get('patients').length,['admin','receptionist'],'Patients','blue'],['Patients today',q.length,0,'activity','teal'],['Waiting',n(['Waiting']),0,'clock','amber'],
  ['Being served',n(['Called','In Consultation']),0,'Doctors','violet'],['Completed',n(['Completed']),0,'check','green'],['No-show',n(['No-Show']),0,'userx','red'],['Appointments today',ap.length,0,'Appointments','blue'],
  ['Cancelled appointments',DB.get('appointments').filter(a=>a.status==='Cancelled').length,['admin','receptionist'],'xcircle','gray'],
  ['Available doctors',DB.get('doctors').filter(d=>d.active&&d.avail==='Available').length,['admin','receptionist'],'Doctors','teal']].filter(c=>!c[2]||c[2].includes(u.role));
 const st=[['Waiting','amber'],['Called','blue'],['In Consultation','violet'],['Completed','green'],['No-Show','red'],['Cancelled','gray']],mx=Math.max(1,...st.map(s=>n([s[0]])));
 const docs=DB.get('doctors').filter(d=>d.active).slice(0,6),dn=id=>deptName(id);
 return html`<div><${PageHead} title="Dashboard" sub=${"Today's activity at a glance"}/>
 <div class=stats>${cards.map(c=>html`<div class=stat><span class=${'ico tone-'+c[4]}><${Icon} n=${c[3]} size=22/></span><div><span>${c[0]}</span><b>${c[1]}</b></div></div>`)}</div>
 <div class=cols><div class=card><div class=cardhead><h3>Today's queue by status</h3></div>
 ${st.map(s=>html`<div class=barrow><span>${s[0]}</span><div class=track><div class=${'fill '+s[1]} style=${{width:(n([s[0]])/mx*100)+'%'}}></div></div><b>${n([s[0]])}</b></div>`)}</div>
 ${staff&&html`<div class=card><div class=cardhead><h3>Doctors</h3><span class=pill>${DB.get('doctors').filter(d=>d.active&&d.avail==='Available').length} available</span></div>
 <div class=list>${docs.length?docs.map(d=>html`<div class=row><${Avatar} name=${d.name} size=38/><div class=grow><b>${d.name}</b><small>${d.spec} · ${dn(d.deptId)}</small></div><${Badge} t=${d.avail}/></div>`):html`<p class=muted>No doctors yet.</p>`}</div></div>`}
 </div></div>`}};
