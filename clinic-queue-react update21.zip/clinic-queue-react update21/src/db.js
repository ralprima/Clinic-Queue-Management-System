// Data layer: tables persisted in localStorage (stand-in for MySQL clinic_queue_db).
const html=htm.bind(React.createElement),{useState,useEffect}=React;
const TABLES=['users','patients','doctors','departments','appointments','queues','notifications','activity_logs','settings'];
const today=()=>new Date().toISOString().slice(0,10);
const DB={
 get:t=>JSON.parse(localStorage.getItem('cq_'+t)||'[]'),
 set:(t,v)=>localStorage.setItem('cq_'+t,JSON.stringify(v)),
 add(t,r){r={id:'i'+Math.random().toString(36).slice(2,10),...r};DB.set(t,[...DB.get(t),r]);return r},
 upd:(t,id,p)=>DB.set(t,DB.get(t).map(r=>r.id===id?{...r,...p}:r)),
 log(a){DB.add('activity_logs',{user:(typeof Auth!=='undefined'&&Auth.user||{}).username||'system',action:a,at:Date.now()})},
 seed(){if(DB.get('departments').length)return;
  const d=['General Consultation:GC','Dental:DN','Pediatrics:PD','Laboratory:LB'].map(s=>{const[name,code]=s.split(':');return DB.add('departments',{name,code,active:true})});
  DB.add('doctors',{name:'Dr. Reyes',spec:'General Medicine',deptId:d[0].id,phone:'09170000001',email:'reyes@clinic.ph',avail:'Available',days:'Mon-Fri 9-17',active:true});
  DB.add('doctors',{name:'Dr. Santos',spec:'Pediatrics',deptId:d[2].id,phone:'09170000002',email:'santos@clinic.ph',avail:'Available',days:'Mon-Sat 8-12',active:true})}
};
