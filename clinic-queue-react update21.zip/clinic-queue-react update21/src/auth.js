const Pages={};
const ROLES=['admin','receptionist','doctor'];
const Can=(role,page)=>!!Pages[page]&&Pages[page].roles.includes(role);
const sha=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
const Auth={user:null,
 async hash(p,salt=Math.random().toString(36).slice(2)){return salt+':'+await sha(salt+p)},
 async check(p,h){const[s]=h.split(':');return h===await Auth.hash(p,s)},
 async init(){DB.seed();if(DB.get('users').length)return;const doc=DB.get('doctors')[0];
  for(const[u,r]of[['admin','admin'],['reception','receptionist'],['doctor','doctor']])DB.add('users',{username:u,role:r,hash:await Auth.hash('Passw0rd!'),doctorId:r==='doctor'?doc.id:null,active:true})},
 async login(u,p){const x=DB.get('users').find(r=>r.username===u&&r.active);
  if(!x||!await Auth.check(p,x.hash))throw Error('Incorrect username or password');Auth.user=x;DB.log('Login');return x},
 logout(){DB.log('Logout');Auth.user=null}};
function Login({onLogin}){const[u,setU]=useState(''),[p,setP]=useState(''),[e,setE]=useState('');
 const go=async()=>{try{onLogin(await Auth.login(u,p))}catch(x){setE(x.message)}};
 const clinic=(DB.get('settings')[0]||{}).clinic||'Clinic Queue';
 return html`<div class=auth><div class=auth-art><div class=brand><span class=logo><${Icon} n=cross size=22/></span><div><b>${clinic}</b><small>Queue Management System</small></div></div>
 <div><h1>Shorter waits.<br/>Better care.</h1><p>One place for patient registration, queue numbers, appointments and live waiting-room displays.</p>
 <ul class=feats><li><span class=ico><${Icon} n=zap size=18/></span>Automatic queue numbers with priority lanes</li><li><span class=ico><${Icon} n=Appointments size=18/></span>Appointment scheduling with conflict checks</li><li><span class=ico><${Icon} n=shield size=18/></span>Role-based access for admin, reception and doctors</li></ul></div>
 <div class=auth-foot>Secure staff access only</div></div>
 <div class=auth-form><div class=auth-card><h2>Welcome back</h2><p class=muted>Sign in to your clinic account</p>
 <label>Username<input value=${u} onInput=${x=>setU(x.target.value)} autocomplete=username/></label>
 <label>Password<input type=password value=${p} onInput=${x=>setP(x.target.value)} onKeyDown=${x=>x.key==='Enter'&&go()} autocomplete=current-password/></label>
 <button onClick=${go}>Sign in</button><span class=err>${e}</span>
 <div class=demo>Demo accounts: <b>admin</b>, <b>reception</b>, <b>doctor</b><br/>Password: <b>Passw0rd!</b></div></div></div></div>`}
