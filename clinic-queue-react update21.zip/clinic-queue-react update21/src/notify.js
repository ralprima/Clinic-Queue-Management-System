// Notifications are raised from queue/appointment events by hooking the activity log.
const _log=DB.log;
DB.log=a=>{_log(a);if(/queue|appointments/i.test(a))DB.add('notifications',{msg:a,at:Date.now(),read:false})};
function Bell(){const[,r]=useState(0),[open,setOpen]=useState(false);useEffect(()=>{const t=setInterval(()=>r(x=>x+1),2000);return()=>clearInterval(t)},[]);
 const ns=DB.get('notifications').slice(-8).reverse(),un=DB.get('notifications').filter(n=>!n.read).length;
 return html`<div class=bellwrap><button class=iconbtn aria-label="Alerts" onClick=${()=>{setOpen(!open);DB.set('notifications',DB.get('notifications').map(n=>({...n,read:true})))}}><${Icon} n=bell/>${un?html`<span class=dot>${un>9?'9+':un}</span>`:null}</button>
 ${open&&html`<div class=pop><div class=pophead>Notifications</div>${ns.length?ns.map(n=>html`<div class=popitem>${n.msg}<small>${new Date(n.at).toLocaleTimeString()}</small></div>`):html`<p class=muted>Nothing new.</p>`}</div>`}</div>`}
