// Public display: queue numbers only, no patient names. Opens in its own tab from the sidebar (index.html#display).
Pages.Display={roles:ROLES,C(){
 const[,r]=useState(0);useEffect(()=>{const t=setInterval(()=>r(x=>x+1),2000);return()=>clearInterval(t)},[]);
 const now=DB.get('queues').filter(x=>x.date===today()&&['Called','In Consultation'].includes(x.status)).sort((a,b)=>(b.calledAt||0)-(a.calledAt||0));
 const dn=id=>(DB.get('doctors').find(d=>d.id===id)||{}).name||'';
 const clinic=(DB.get('settings')[0]||{}).clinic||'Clinic Queue',d=new Date(),next=Q.waiting().slice(0,6);
 return html`<div class=tv><div class=tvhead><div class=brand><span class=logo><${Icon} n=cross size=22/></span><div><b>${clinic}</b><small>Patient queue</small></div></div>
 <div class=tvclock><b>${d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</b><small>${d.toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'})}</small></div></div>
 <div class=tvbody><section><h1>Now serving</h1>${now.length?html`<div class=tvgrid>${now.map((x,i)=>html`<div class=${'tvcard'+(i?'':' hot')}><div class=tvno>${x.no}</div>
 <div class=tvmeta><b>${deptName(x.deptId)}</b><span>${dn(x.doctorId)}</span></div><span class=tvstatus>${x.status}</span></div>`)}</div>`:html`<p class=tvempty>No patient is being called.</p>`}</section>
 <aside><h2>Next in line</h2>${next.length?next.map(w=>html`<div class=tvnext><b>${w.no}</b><span>${deptName(w.deptId)}</span></div>`):html`<p class=tvempty>—</p>`}</aside></div></div>`}};
