const deptName=id=>(DB.get('departments').find(d=>d.id===id)||{}).name||'';
const deptOpts=()=>DB.get('departments').filter(d=>d.active).map(d=>({v:d.id,t:d.name}));
Pages.Doctors={roles:['admin'],C:()=>html`<${Crud} table=doctors title="Doctors" sub="Doctor profiles, specializations and weekly schedules"
 fields=${[{k:'name',label:'Full name',req:1,fmt:v=>html`<span class=person><${Avatar} name=${v}/><span>${v.replace(/^Dr\.? /,'Dr.\u00a0')}</span></span>`},{k:'spec',label:'Specialization',req:1},{k:'deptId',label:'Department',opts:deptOpts,fmt:deptName,req:1},
 {k:'avail',label:'Availability',opts:['Available','On leave','Busy'],fmt:v=>html`<${Badge} t=${v}/>`,req:1},
 {k:'phone',label:'Contact number',req:1},{k:'email',label:'Email',type:'email',req:1},{k:'days',label:'Schedule (days/hours)'}]}
 validate=${f=>!phoneOk(f.phone)?'Enter a valid contact number':!/^\S+@\S+\.\S+$/.test(f.email)?'Enter a valid email address':''}/>`};
Pages.Departments={roles:['admin'],C:()=>html`<${Crud} table=departments title="Departments" sub="Clinic departments and their queue-number prefixes"
 fields=${[{k:'name',label:'Department / service',req:1},{k:'code',label:'Queue code (2 letters)',fmt:v=>html`<span class=code>${v&&v.toUpperCase()}</span>`,req:1}]}
 validate=${(f,all)=>!/^[A-Za-z]{2}$/.test(f.code)?'Queue code must be 2 letters':all.some(d=>d.id!==f.id&&d.code.toUpperCase()===f.code.toUpperCase())?'Queue code already in use':''}/>`};
