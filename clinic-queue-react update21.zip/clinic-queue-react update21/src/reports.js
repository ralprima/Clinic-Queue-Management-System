const dl=(name,text,type)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click()};
Pages.Reports={roles:['admin'],C(){
 const[per,setPer]=useState(1),[q,setQ]=useState(''),from=new Date(Date.now()-(per-1)*864e5).toISOString().slice(0,10);
 const rows=DB.get('queues').filter(x=>x.date>=from&&JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
 const waits=rows.filter(x=>x.calledAt).map(x=>(x.calledAt-x.created)/6e4),avg=waits.length?(waits.reduce((a,b)=>a+b,0)/waits.length).toFixed(1):'n/a';
 const cnt=s=>rows.filter(x=>x.status===s).length;
 const csv=()=>dl('queue-report.csv',['Queue,Date,Department,Priority,Status',...rows.map(x=>[x.no,x.date,deptName(x.deptId),x.priority,x.status].join(','))].join('\n'),'text/csv');
 return html`<div><${PageHead} title="Reports" sub="Queue performance for the selected period"><button class=ghost onClick=${csv}><${Icon} n=download size=16/>Export Excel (CSV)</button><button onClick=${()=>print()}><${Icon} n=printer size=16/>Print / Save as PDF</button><//>
 <div class="card noprint"><div class=grid><label>Period<select value=${per} onChange=${e=>setPer(+e.target.value)}><option value=1>Daily</option><option value=7>Weekly</option><option value=30>Monthly</option></select></label>
 <label>Search<input value=${q} onInput=${e=>setQ(e.target.value)} placeholder="Number, department, status…"/></label></div></div>
 <div class=sumrow><div class=sum><b>${rows.length}</b><span>Total</span></div><div class=sum><b>${cnt('Completed')}</b><span>Completed</span></div><div class=sum><b>${cnt('No-Show')}</b><span>No-show</span></div>
 <div class=sum><b>${cnt('Cancelled')}</b><span>Cancelled</span></div><div class=sum><b>${avg}${avg==='n/a'?'':' min'}</b><span>Average wait</span></div></div>
 <div class=tablewrap><table><thead><tr><th>No.</th><th>Date</th><th>Department</th><th>Priority</th><th>Status</th></tr></thead><tbody>
 ${rows.length?rows.map(x=>html`<tr><td><b class=qno>${x.no}</b></td><td>${x.date}</td><td>${deptName(x.deptId)}</td><td><${Badge} t=${x.priority}/></td><td><${Badge} t=${x.status}/></td></tr>`):html`<tr><td class=empty colspan=5>No queue entries in this period.</td></tr>`}</tbody></table></div></div>`}};
Pages.Logs={roles:['admin'],C:()=>html`<div><${PageHead} title="Activity logs" sub="The 200 most recent actions by staff"/><div class=tablewrap><table><thead><tr><th>When</th><th>User</th><th>Activity</th></tr></thead><tbody>${DB.get('activity_logs').slice(-200).reverse().map(l=>html`<tr><td>${new Date(l.at).toLocaleString()}</td><td><span class=person><${Avatar} name=${l.user} size=26/>${l.user}</span></td><td>${l.action}</td></tr>`)}</tbody></table></div></div>`};
Pages.Settings={roles:['admin'],C(){
 const[n,setN]=useState((DB.get('settings')[0]||{}).clinic||''),[m,setM]=useState('');
 const backup=()=>dl('clinic-backup.json',JSON.stringify(Object.fromEntries(TABLES.map(t=>[t,DB.get(t)]))),'application/json');
 const restore=e=>{const fr=new FileReader();fr.onload=()=>{try{const d=JSON.parse(fr.result);TABLES.forEach(t=>d[t]&&DB.set(t,d[t]));DB.log('Database restored');setM('Restored. Reload the page.')}catch{setM('That file is not a valid backup.')}};fr.readAsText(e.target.files[0])};
 return html`<div><${PageHead} title="Settings" sub="Clinic details and data backup"/>
 <div class=card><div class=cardhead><h3>Clinic</h3></div><div class=grid><label>Clinic name<input value=${n} onInput=${e=>setN(e.target.value)}/></label></div>
 <div class=formfoot><button class=ok onClick=${()=>{DB.set('settings',[{id:'cfg',clinic:n}]);DB.log('Updated settings');setM('Saved. Reload to see the new name.')}}>Save settings</button></div></div>
 <div class=card><div class=cardhead><h3>Backup and restore</h3></div><div class=grid><label>Restore from backup<input type=file accept=.json onChange=${restore}/></label></div>
 <div class=formfoot><button class=ghost onClick=${backup}><${Icon} n=download size=16/>Back up database</button><span class=muted>${m}</span></div></div></div>`}};
