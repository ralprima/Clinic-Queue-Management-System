# Clinic Queue Management System (React)

React port of the C# WinForms/MySQL specification. Runs as static files; open `index.html` (or `npx serve .`) in Chrome/Edge. React and htm load from CDN, so the first run needs internet.

**Demo logins** (password `Passw0rd!`): `admin`, `reception`, `doctor`. Live TV display: `index.html#display`.

## Structure
`src/db.js` data layer + seed · `auth.js` login, hashing, roles · `crud.js` shared table/form · `patients.js`, `staff.js` (doctors, departments), `queue.js`, `appointments.js`, `display.js`, `notify.js`, `reports.js` (reports, logs, settings) · `test/run.js` logic tests (`npm test`).

## Differences from the spec
- **Storage is browser localStorage, not MySQL.** Data lives in one browser; there is no server, so the TV display must run in the same browser profile. A Node/Express + MySQL API behind `DB` is the next step.
- Passwords use salted SHA-256 in the browser (demo-grade, not BCrypt) and role checks are client-side only.
- Excel export is CSV; PDF is the browser's Print → Save as PDF.
- Not built: separate clinic-services table, per-slot doctor schedules (free-text schedule only), consultation notes/diagnosis form, queue-format and priority settings, user-management screen, SQL scripts.
- Priority: Senior, PWD and Pregnant share one tier ahead of Regular, first-come within tier. Adjust `PRI` in `queue.js` to match your clinic policy.

## Tests
`npm test` covers login, hashing, roles, queue numbering, priority, duplicates, skip/cancel, appointment conflicts. UI screens were not exercised in a browser.
