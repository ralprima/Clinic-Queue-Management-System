const PRI={PWD:0,Senior:0,Pregnant:0,Regular:1},ACTIVE=['Waiting','Called','In Consultation'];
const Q={
 issue({patientId,deptId,priority}){
  const qs=DB.get('queues'),d=today();
  if(qs.some(x=>x.patientId===patientId&&x.date===d&&ACTIVE.includes(x.status)))throw Error('Patient already has an active queue entry');
  const dept=DB.get('departments').find(x=>x.id===deptId);if(!dept)throw Error('Select a department');
  const doc=doctorOf(deptId);if(!doc)throw Error('This department has no active doctor');// the department's one doctor is assigned automatically
  const n=qs.filter(x=>x.date===d&&x.deptId===deptId).length+1,no=dept.code.toUpperCase()+'-'+String(n).padStart(3,'0');
  const r=DB.add('queues',{no,patientId,deptId,doctorId:doc.id,priority:priority||'Regular',date:d,status:'Waiting',created:Date.now(),at:Date.now()});
  DB.log(`Queue ${no} issued`);return r},
 waiting:deptId=>DB.get('queues').filter(x=>x.date===today()&&x.status==='Waiting'&&(!deptId||x.deptId===deptId)).sort((a,b)=>PRI[a.priority]-PRI[b.priority]||a.at-b.at),
 set(id,status,extra={}){const r=DB.get('queues').find(x=>x.id===id);DB.upd('queues',id,{status,...extra});DB.log(`Queue ${r.no} ${status}`)},
 callNext(deptId){const n=Q.waiting(deptId)[0];if(!n)throw Error('No waiting patients');Q.set(n.id,'Called',{calledAt:Date.now()});return n},
 skip(id){const r=DB.get('queues').find(x=>x.id===id);DB.upd('queues',id,{status:'Waiting',at:Date.now()});DB.log(`Queue ${r.no} skipped`)}
};
const pName=id=>{const p=DB.get('patients').find(x=>x.id===id);return p?p.last+', '+p.first:''};
Pages.Queue={roles:ROLES,C(){
 const[,r]=useState(0),re=()=>r(x=>x+1),[f,setF]=useState({priority:'Regular'}),[err,setErr]=useState(''),[hist,setHist]=useState(false);
 const u=Auth.user,doc=u.role==='doctor',dept=doc?deptOfDoctor(u.doctorId):null,run=fn=>()=>{try{fn();setErr('')}catch(e){setErr(e.message)}re()};
 const rows=DB.get('queues').filter(x=>(hist||x.date===today())&&(!doc||x.deptId===dept)).sort((a,b)=>b.created-a.created);
 const btn=(t,cls,fn)=>html`<button class=${cls} onClick=${run(fn)}>${t}</button> `;
 const act=x=>({Waiting:[['Cancel','bad',()=>Q.set(x.id,'Cancelled')]],Called:[['Recall','warn',()=>Q.set(x.id,'Called',{calledAt:Date.now()})],['Skip','warn',()=>Q.skip(x.id)],
  ['Start','ok',()=>Q.set(x.id,'In Consultation')],['No-show','bad',()=>Q.set(x.id,'No-Show')]],'In Consultation':[['Complete','ok',()=>Q.set(x.id,'Completed',{doneAt:Date.now()})]]}[x.status]||[]).map(a=>btn(...a));
 const wl=Q.waiting(dept);
 return html`<div><${PageHead} title="Queue" sub=${doc?deptName(dept)+" queue: call and serve your patients":"Issue numbers, call patients and follow today's flow"}><label class=check><input type=checkbox checked=${hist} onChange=${e=>setHist(e.target.checked)}/> Show queue history</label><//>
 ${!doc&&html`<div class="card form"><div class=cardhead><h3>Issue a queue number</h3></div><div class=grid>
 <label>Patient<select value=${f.patientId||''} onChange=${e=>setF({...f,patientId:e.target.value})}><option value="">Select…</option>${DB.get('patients').filter(p=>p.active).map(p=>html`<option value=${p.id}>${pName(p.id)}</option>`)}</select></label>
 <label>Department<select value=${f.deptId||''} onChange=${e=>setF({...f,deptId:e.target.value})}><option value="">Select…</option>${deptOpts().map(o=>html`<option value=${o.v}>${o.t}</option>`)}</select></label>
 <label>Doctor<input disabled value=${f.deptId?(doctorOf(f.deptId)||{name:'No doctor assigned'}).name:'Assigned from department'}/></label>
 <label>Priority<select value=${f.priority} onChange=${e=>setF({...f,priority:e.target.value})}>${['Regular',...Object.keys(PRI).filter(p=>p!=='Regular')].map(p=>html`<option>${p}</option>`)}</select></label></div>
 <div class=formfoot>${btn('Issue queue number','ok',()=>{if(!f.patientId)throw Error('Select a patient');Q.issue(f)})}<span class=err>${err}</span></div></div>`}
 <div class=card><div class=cardhead><h3>Waiting list</h3><span class=pill>${wl.length} waiting</span></div>
 <div class=chips>${wl.length?wl.map(w=>html`<span class=${'chip'+(w.priority==='Regular'?'':' pri')}>${w.no}${w.priority==='Regular'?'':html` <small>${w.priority}</small>`}</span>`):html`<span class=muted>Nobody is waiting.</span>`}</div>
 <div class=callrow>${deptOpts().filter(o=>!doc||o.v===dept).map(o=>btn('Call next: '+o.t,'',()=>Q.callNext(o.v)))}</div>${doc&&err?html`<p class=err>${err}</p>`:null}</div>
 <div class=tablewrap><table><thead><tr><th>No.</th><th>Date</th><th>Patient</th><th>Priority</th><th>Status</th><th></th></tr></thead><tbody>
 ${rows.length?rows.map(x=>html`<tr><td><b class=qno>${x.no}</b></td><td>${x.date}</td><td>${pName(x.patientId)}</td><td><${Badge} t=${x.priority}/></td><td><${Badge} t=${x.status}/></td><td>${act(x)}</td></tr>`):html`<tr><td class=empty colspan=6>No queue entries yet.</td></tr>`}</tbody></table></div></div>`}};
