// Data layer: tables persisted in localStorage (stand-in for MySQL clinic_queue_db).
const html=htm.bind(React.createElement),{useState,useEffect}=React;
const TABLES=['users','patients','doctors','departments','appointments','queues','notifications','activity_logs','settings'];
const today=()=>new Date().toISOString().slice(0,10);
// One doctor per department. Seeded on first run; existing installs are migrated once (see seed()). Matched by email, never duplicated.
const ROSTER=[
 ['Dr. Miguel Reyes','General Medicine','GC','09170000001','reyes@clinic.ph','Available','Mon-Fri 9-17'],
 ['Dr. Rafael Bautista','General Dentistry','DN','09170000006','bautista@clinic.ph','Available','Mon-Fri 9-17'],
 ['Dr. Ana Santos','Pediatrics','PD','09170000002','santos@clinic.ph','Available','Mon-Sat 8-12'],
 ['Dr. Camille Torres','Clinical Pathology','LB','09170000011','torres@clinic.ph','Available','Mon-Sat 7-15']];
const DB={
 get:t=>JSON.parse(localStorage.getItem('cq_'+t)||'[]'),
 set:(t,v)=>localStorage.setItem('cq_'+t,JSON.stringify(v)),
 add(t,r){r={id:'i'+Math.random().toString(36).slice(2,10),...r};DB.set(t,[...DB.get(t),r]);return r},
 upd:(t,id,p)=>DB.set(t,DB.get(t).map(r=>r.id===id?{...r,...p}:r)),
 log(a){DB.add('activity_logs',{user:(typeof Auth!=='undefined'&&Auth.user||{}).username||'system',action:a,at:Date.now()})},
 seed(){if(!DB.get('departments').length)
  ['General Consultation:GC','Dental:DN','Pediatrics:PD','Laboratory:LB'].forEach(s=>{const[name,code]=s.split(':');DB.add('departments',{name,code,active:true})});
  if(localStorage.getItem('cq_roster')!=='2'){const ds=DB.get('departments'),keep=ROSTER.map(r=>r[4]);
   for(const[name,spec,code,phone,email,avail,days]of ROSTER){const d=ds.find(x=>x.code===code),h=DB.get('doctors').find(x=>x.email===email);
    if(h)DB.upd('doctors',h.id,{active:true});else if(d)DB.add('doctors',{name,spec,deptId:d.id,phone,email,avail,days,active:true})}
   // Enforce one active doctor per department: keep the roster doctor (else the first one), deactivate the rest. Records are kept so history still shows names.
   for(const d of ds){const mine=DB.get('doctors').filter(x=>x.deptId===d.id&&x.active),pick=mine.find(x=>keep.includes(x.email))||mine[0];
    mine.filter(x=>x!==pick).forEach(x=>DB.upd('doctors',x.id,{active:false}))}
   localStorage.setItem('cq_roster','2')}}
};
// The department's single active doctor, and the department a doctor works in.
const doctorOf=deptId=>DB.get('doctors').find(d=>d.deptId===deptId&&d.active);
const deptOfDoctor=id=>(DB.get('doctors').find(d=>d.id===id)||{}).deptId;
